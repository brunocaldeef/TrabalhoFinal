
const calcular = document.querySelector<HTMLButtonElement>('#calcular')!;


function imc () {
    let nome : string = document.querySelector<HTMLInputElement>('#nome')!.value;
    let altura: number  =document.querySelector<HTMLInputElement>('#altura')!.valueAsNumber;
    let peso: number  =document.querySelector<HTMLInputElement>('#peso')!.valueAsNumber;
    let resultado =document.querySelector<HTMLDivElement>('#resultado')!;

    if (nome !== "" && altura !== null && peso !== null ){

        let valorIMC : number  = (peso / (altura * altura)).toFixed(1);

        let classificacao = '';

        if (valorIMC < 18.5){
            classificacao = 'abaixo do peso.';
        }else if (valorIMC < 25) {
            classificacao = 'com peso ideal. Parabéns!!!';
        }else if (valorIMC < 30){
            classificacao = 'levemente acima do peso.';
        }else if (valorIMC < 35){
            classificacao = 'com obesidade grau I.';
        }else if (valorIMC < 40){
            classificacao = 'com obesidade grau II';
        }else {
            classificacao = 'com obesidade grau III. Cuidado!!';
        }

        resultado.textContent = `${nome} seu IMC é ${valorIMC} e você está ${classificacao}`;
        
    }else {
        resultado.textContent = 'Preencha todos os campos!!!';
    }

}

calcular.addEventListener('click', imc);