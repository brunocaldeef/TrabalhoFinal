"use strict";
var calcular = document.querySelector('#calcular');
function imc() {
    var nome = document.querySelector('#nome').value;
    var altura = document.querySelector('#altura').valueAsNumber;
    var peso = document.querySelector('#peso').valueAsNumber;
    var resultado = document.querySelector('#resultado');
    if (nome !== "" && altura !== null && peso !== null) {
        var valorIMC = (peso / (altura * altura)).toFixed(1);
        var classificacao = '';
        if (valorIMC < 18.5) {
            classificacao = 'abaixo do peso.';
        }
        else if (valorIMC < 25) {
            classificacao = 'com peso ideal. Parabéns!!!';
        }
        else if (valorIMC < 30) {
            classificacao = 'levemente acima do peso.';
        }
        else if (valorIMC < 35) {
            classificacao = 'com obesidade grau I.';
        }
        else if (valorIMC < 40) {
            classificacao = 'com obesidade grau II';
        }
        else {
            classificacao = 'com obesidade grau III. Cuidado!!';
        }
        resultado.textContent = nome + " seu IMC \u00E9 " + valorIMC + " e voc\u00EA est\u00E1 " + classificacao;
    }
    else {
        resultado.textContent = 'Preencha todos os campos!!!';
    }
}
calcular.addEventListener('click', imc);
